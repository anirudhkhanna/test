var mongoose = require('mongoose');

var studentSchema = mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	age: {
		type: String
	}
});

var Student = mongoose.model('CollegeDB', studentSchema, 'Students'); /* db_name, schema, collection */


/* Creating a query API */
module.exports.getStudent = function(callback, limit) {

	Student.find(callback).limit(limit);
}

module.exports.getStudentById = function(id, callback) {

	Student.findById(id, callback);	// id is unique in mongo, so no limit necessary
}

module.exports.getStudentByName = function(name_param, callback) {

	var query = {name: name_param};
	Student.findOne(query, callback);
}

module.exports.addStudent = function(param, callback) {

	Student.create(param, callback);
}
