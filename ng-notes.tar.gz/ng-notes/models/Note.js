var mongoose = require('mongoose');

var noteSchema = mongoose.Schema({
	index: {
		type: Number,
	},
	title: {
		type: String
	},
	content: {
		type: String
	},
	dateCreated: {
		type: String,
	},
	labels: {
		type: [],
	},
	colorClass: {
		type: String,
	},
	isArchived: {
		type: Boolean,
	},
	isTrashed: {
		type: Boolean,
	},
	author: {
		type: String,
	}
});

mongoose.model('Note', noteSchema);
