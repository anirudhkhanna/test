
/* Notes app */
var app = angular.module('notesApp');

/* Loading bar element */
var cfpLoadingBarElem = null;

app.controller('landingController', function($location, $state, cfpLoadingBar, authentication) {

	/* Assign the loading bar element for use outside the controller */
	cfpLoadingBarElem = cfpLoadingBar;

	var vm = this;

	vm.signinCredentials = {
		email: '',
		password: ''
	};

	vm.registerCredentials = {
		name: '',
		email: '',
		password: '',
		avatar: 'default-user-avatar-0.png'
	};

	vm.signin = function() {

		authentication.signin(vm.signinCredentials)
			.error(function(err) {
				alert(err.message);
			})
			.then(function() {
				$state.go('notes.state-notes');
			});
	};

	vm.register = function() {

		authentication.register(vm.registerCredentials)
			.error(function(err) {
				alert(err.message);
			})
			.then(function() {
				$state.go('notes.state-notes');
			});
	};
});
