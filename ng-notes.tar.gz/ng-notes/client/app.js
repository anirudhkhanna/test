
/* Notes app */
var app = angular.module('notesApp', ['froala', 'ui.router', 'chieffancypants.loadingBar' /* , 'angular-loading-bar'*/ ]);

/* Configuration for UI-Router routes */
app.config(function($stateProvider, $urlRouterProvider) {

	$urlRouterProvider.otherwise('/landing');

	$stateProvider
		.state('landing', {
			name: 'landing',
			url: '/landing',
			templateUrl: '/views/landing.view.html',
			controller: 'landingController as vm',
		})
		.state('notes', {
			name: 'notes',
			url: '/notes',
			templateUrl: '/views/notes.view.html',
			controller: 'notesController as vm',
		})
		.state('notes.state-notes', {
			url: '/notes',
			templateUrl: 'views/sub-views/notes.view.html'
		})
		.state('notes.state-archive', {
			url: '/archive',
			templateUrl: 'views/sub-views/archive.view.html'
		})
		.state('notes.state-trash', {
			url: '/trash',
			templateUrl: 'views/sub-views/trash.view.html'
		})
		.state('notes.state-labels', {
			url: '/labels',
			templateUrl: 'views/sub-views/labels.view.html'
		});
});

/* Handle state changes done in between views by UI-Router */
app.run(function($rootScope, $state, authentication) {

	$rootScope
		.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {

			if(toState.name === 'notes' && !authentication.isLoggedIn()) {
				event.preventDefault();
				$state.go('landing');
			}

			if(toState.name === 'notes.state-notes' && !authentication.isLoggedIn()) {
				event.preventDefault();
				$state.go('landing');
			}

			if(toState.name === 'notes.state-archive' && !authentication.isLoggedIn()) {
				event.preventDefault();
				$state.go('landing');
			}

			if(toState.name === 'notes.state-trash' && !authentication.isLoggedIn()) {
				event.preventDefault();
				$state.go('landing');
			}

			if(toState.name === 'notes.state-labels' && !authentication.isLoggedIn()) {
				event.preventDefault();
				$state.go('landing');
			}

			if(toState.name === 'landing' && authentication.isLoggedIn()) {
				event.preventDefault();
				$state.go('notes.state-notes');
			}
	});
});
