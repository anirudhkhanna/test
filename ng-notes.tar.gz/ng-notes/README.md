# ng-notes
A simple note-taking web app to quickly capture what is on your mind - ideas, pictures, lists and more.

Built with MEAN stack (MongoDB, Express, AngularJS and Node.js). The UX is largely based on AngularJS - hence the name ng-notes. ☺

Inspired by Google Keep.

**Front-end Demo:** https://anirudhkhanna.github.io/ng-notes
