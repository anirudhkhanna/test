# ng-notes
A simple notes app built with AngularJS
