var mongoose = require('mongoose');

var userSchema = mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	email: {
		type: String
	}
});

// create the User modal
var User = mongoose.model('user', userSchema);


/* Creating a query API */
module.exports.getUsers = function(callback, limit) {

	User.find(callback).limit(limit);
}

module.exports.getUserById = function(id, callback) {

	User.findById(id, callback);	// id is unique in MongoDB
}