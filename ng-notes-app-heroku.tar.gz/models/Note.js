var mongoose = require('mongoose');

var noteSchema = mongoose.Schema({
	index: {
		type: Number,
	},
	title: {
		type: String
	},
	content: {
		type: String
	},
	dateCreated: {
		type: String,
	},
	labels: {
		type: [],
	},
	colorClass: {
		type: String,
	},
	isArchived: {
		type: Boolean,
	},
	isTrashed: {
		type: Boolean,
	},
	author: {
		type: String,
	}
});

// create the Note modal
var Note = mongoose.model('note', noteSchema);


/* Creating a query API */
module.exports.getNotes = function(callback, limit) {

	Note.find(callback).limit(limit);
}

module.exports.getNoteById = function(id, callback) {

	Note.findById(id, callback);
}

module.exports.getNotesByAuthorId = function(aid, callback) {

	var query = {author: aid};
	Note.find(query, callback);
}

module.exports.addNote = function(param, callback) {

	Note.create(param, callback);
}

module.exports.deleteNoteById = function(id, callback) {

	var query = {_id: id};
	Note.remove(query, callback);
}

module.exports.deleteNotesByAuthorId = function(aid, callback) {

	var query = {author: aid};
	Note.remove(query, callback);
}



/*
module.exports.delStudent = function(name_param, callback) {

	var query = {name: name_param};
	Student.remove(query, callback);
}
*/