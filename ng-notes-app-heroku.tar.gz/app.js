var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());


app.set('port', (process.env.PORT || 7000));


var mongoose = require('mongoose');
var config = require('./mongoose-config.json');
var User = require('./models/User.js');
var Note = require('./models/Note.js');

/* mongoose.connect('mongodb://localhost:27017/db_name'); */
mongoose.connect(config.connectionString, function(err) {
	if(err)
		console.log('Mongoose connection to ' + config.connectionString + ' failed: ' + err);
	else
		console.log('Connected to: ' + config.connectionString);
});

var db = mongoose.connection;


/* Static */
app.use(express.static(__dirname + '/static'));


/* Test */
app.get('/test', function(req, res) {

	console.log("In method test");
	res.end("Hello, test!");
});


/* Notes API */

/* Fetch all notes */
app.get('/notes', function(req, res) {

	Note.getNotes(function(err, notes) {

		if(err) {
			throw err;
		}
		else {
			res.json(notes);
		}
	} /* , lim */);
});

/* Fetch a note by id */
app.get('/notes/:id', function(req, res) {

	var id = req.params.id;
	Note.getNoteById(id, function(err, note) {

		if(err) {
			throw err;
		}
		else {
			res.json(note);
		}
	});
});

/* Fetch notes by author id */
app.get('/notesbyauthorid/:author', function(req, res) {

	var author = req.params.author;
	Note.getNotesByAuthorId(author, function(err, notes) {

		if(err) {
			throw err;
		}
		else {
			res.json(notes);
		}
	});
});

/* Add a note */
app.post('/addnote', function(req, res) {

	var note = req.body;
	Note.addNote(note, function(err, note) {

		if(err) {
			throw err;
		}
		else {
			res.json(note);
		}
	});
});

/* Delete note by id */
app.delete('/deletenotebyid/:id', function(req, res) {

	var id = req.params.id;
	Note.deleteNoteById(id, function(err, notes) {
		if(err) {
			throw err;
		}
		else {
			res.json(notes);
		}
	});
});

/* Delete notes by author id */
app.delete('/deletenotesbyauthorid/:author', function(req, res) {

	var author = req.params.author;
	Note.deleteNotesByAuthorId(author, function(err, notes) {
		if(err) {
			throw err;
		}
		else {
			res.json(notes);
		}
	});
});


/* Users API */

/* Fetch all users */
app.get('/users', function(req, res) {

	User.getUsers(function(err, users) {

		if(err) {
			throw err;
		}
		else {
			res.json(users);
		}
	} /* , 10 (no limit needed) */);
});

/* Fetch a user by id */
app.get('/users/:id', function(req, res) {

	var id = req.params.id;
	User.getUserById(id, function(err, user) {

		if(err) {
			throw err;
		}
		else {
			res.json(user);
		}
	});
});


// Start the Node server
var server = app.listen(app.get('port'), function() {
	console.log('Node app is running on port', app.get('port'));
});
